class MoreLikeThisDisabledError(Exception):
    pass


class WorkflowHashNotEqualError(Exception):
    pass
