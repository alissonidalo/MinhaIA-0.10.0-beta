from services.errors.base import BaseServiceError


class AppModelConfigBrokenError(BaseServiceError):
    pass
