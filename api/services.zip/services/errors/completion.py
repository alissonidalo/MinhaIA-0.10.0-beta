from services.errors.base import BaseServiceError


class CompletionStoppedError(BaseServiceError):
    pass
