from services.errors.base import BaseServiceError


class IndexNotInitializedError(BaseServiceError):
    pass
