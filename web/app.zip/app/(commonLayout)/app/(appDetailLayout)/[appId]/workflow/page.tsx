'use client'

import Workflow from '@/app/components/workflow'

const Page = () => {
  return (
    <div className='w-full h-full overflow-x-auto'>
      <Workflow />
    </div>
  )
}
export default Page
