import React from 'react'
import ExternalKnowledgeBaseConnector from '@/app/components/datasets/external-knowledge-base/connector'

const ExternalKnowledgeBaseCreation = () => {
  return <ExternalKnowledgeBaseConnector />
}

export default ExternalKnowledgeBaseCreation
