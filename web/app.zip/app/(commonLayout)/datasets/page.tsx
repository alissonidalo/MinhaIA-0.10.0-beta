import Container from './Container'

const AppList = async () => {
  return <Container />
}

export const metadata = {
  title: 'Datasets - Minha IA',
}

export default AppList
