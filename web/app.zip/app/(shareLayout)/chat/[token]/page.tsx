'use client'
import React from 'react'
import ChatWithHistoryWrap from '@/app/components/base/chat/chat-with-history'

const Chat = () => {
  return (
    <ChatWithHistoryWrap />
  )
}

export default React.memo(Chat)
