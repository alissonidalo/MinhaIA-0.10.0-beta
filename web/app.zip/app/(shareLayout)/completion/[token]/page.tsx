import React from 'react'
import Main from '@/app/components/share/text-generation'

const Completion = () => {
  return (
    <Main />
  )
}

export default React.memo(Completion)
