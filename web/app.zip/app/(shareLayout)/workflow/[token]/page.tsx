import React from 'react'

import Main from '@/app/components/share/text-generation'

const Workflow = () => {
  return (
    <Main isWorkflow />
  )
}

export default React.memo(Workflow)
