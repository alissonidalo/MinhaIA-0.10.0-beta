export const isDify = () => {
  return document.referrer.includes('dify.ai')
}
