export enum PageType {
  log = 'log',
  annotation = 'annotation',
}
