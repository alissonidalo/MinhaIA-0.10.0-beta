export const FILE_SIZE_LIMIT = 15 * 1024 * 1024

export const FILE_URL_REGEX = /^(https?|ftp):\/\//
